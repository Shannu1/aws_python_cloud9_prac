print("Hello, World")
print("welcome,to my home") 
print("Python has three numeric types: int, float, and complex")
print("my name is sara " )
print("/n")

myValue=1
hisValue="this is his dog"
print(myValue)
print(hisValue)
print(type(myValue))
print(type(hisValue))


print(str(myValue) + "ïs the data type of "+ str(type(myValue)))

x = hisValue + " and " + str(myValue)

print(x)

def know():
    print(myValue)
    print(type(myValue))
    print(str(myValue) + "ïs the data type of "+ str(type(myValue)))



print("-------------------------")
print("-------------------------")
myValue = "this is a string"
know()
print("-------------------------")
print("-------------------------")
print("Ïntroducing the float data type")
myValue=3.14
know()
print("-------------------------")
print("-------------------------")
print("Ïntroducing the complex data type")
myValue=6j
know()
print("-------------------------")
print("-------------------------")
print("Ïntroducing the bool data type")
myValue=False
know()
print("-------------------------")
print("-------------------------")


myValue=input()
know()

print("-------------------------")
print("-------------------------")


print("working with string concatenation")
print("-------------------")

